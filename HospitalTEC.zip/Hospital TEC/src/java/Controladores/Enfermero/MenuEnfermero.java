/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores.Enfermero;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author valem
 */
public class MenuEnfermero extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String BotonNewAppointment = request.getParameter("NewAppointment"),
                BotonCancelC = request.getParameter("CancelC"),
                BotonReportAppointments = request.getParameter("ReportAppointments"),
                BotonReportDiagnosis = request.getParameter("ReportDiagnosis"),
                BotonReportTreatments = request.getParameter("ReportTreatments"),
                BotonReportAmountAppointment = request.getParameter("ReportAmountAppointment"),
                BotonReportAmountDiagnosis = request.getParameter("ReportAmountDiagnosis"),
                BotonReportAmountTreatments = request.getParameter("ReportAmountTreatments"),
                BotonReportHospitalization = request.getParameter("ReportHospitalization");
        if (BotonNewAppointment != null) {
            RequestDispatcher rd = request.getRequestDispatcher("Doctor/SolicitarCitaD.jsp");
            rd.forward(request, response);
        } else if (BotonCancelC != null) {
            RequestDispatcher rd = request.getRequestDispatcher("Doctor/CancelarCitaD.jsp");
            rd.forward(request, response);
        } else if (BotonReportAppointments != null) {
            RequestDispatcher rd = request.getRequestDispatcher("Doctor/ReporteCitaD.jsp");
            rd.forward(request, response);
        } else if (BotonReportDiagnosis != null) {
            RequestDispatcher rd = request.getRequestDispatcher("Doctor/ReporteDiagnosticoD.jsp");
            rd.forward(request, response);
        } else if (BotonReportTreatments != null) {
            RequestDispatcher rd = request.getRequestDispatcher("Doctor/ReporteTratamientoD.jsp");
            rd.forward(request, response);
        } else if (BotonReportAmountAppointment != null) {
            RequestDispatcher rd = request.getRequestDispatcher("Doctor/ReporteCantidadCD.jsp");
            rd.forward(request, response);
        } else if (BotonReportAmountDiagnosis != null) {
            RequestDispatcher rd = request.getRequestDispatcher("Doctor/ReporteCantidadDD.jsp");
            rd.forward(request, response);
        } else if (BotonReportAmountTreatments != null) {
            RequestDispatcher rd = request.getRequestDispatcher("Doctor/ReporteCantidadTD.jsp");
            rd.forward(request, response);
        } else if (BotonReportHospitalization != null) {
            RequestDispatcher rd = request.getRequestDispatcher("Doctor/ReporteHospitazacionD.jsp");
            rd.forward(request, response);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
