/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class indexC
 */
@WebServlet("/indexC")
public class indexC extends HttpServlet {

    private static final long serialVersionUID = 1L;
    public static int ID;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public indexC() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ID = Integer.parseInt(request.getParameter("ID"));
//        response.setContentType("text/html; charset=UTF-8");
//si es un paciente entra aqui
        if (ID == 1) {
            RequestDispatcher rd = request.getRequestDispatcher("Paciente/MenuPaciente.jsp");
            rd.forward(request, response);
        } else if (ID == 2) {
            RequestDispatcher rd = request.getRequestDispatcher("Secretario/MenuSecretario.jsp");
            rd.forward(request, response);
        } else if (ID == 3) {
            RequestDispatcher rd = request.getRequestDispatcher("Doctor/MenuDoctor.jsp");
            rd.forward(request, response);
        } else if (ID == 4) {
            RequestDispatcher rd = request.getRequestDispatcher("Enfermero/MenuEnfermero.jsp");
            rd.forward(request, response);
        }
    }

}
